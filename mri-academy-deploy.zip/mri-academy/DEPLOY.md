# MRI ACADEMY 배포 가이드 — 3단계

## 준비물
- GitHub 계정 (없으면 github.com에서 무료 가입)
- Vercel 계정 (없으면 vercel.com에서 GitHub으로 로그인)
- Anthropic API 키 (console.anthropic.com → API Keys)

---

## STEP 1 — GitHub에 파일 올리기

1. github.com → 로그인 → 우측 상단 [+] → "New repository"
2. Repository name: `mri-academy`
3. Public 선택 → "Create repository"
4. "uploading an existing file" 클릭
5. 이 폴더 안의 파일들을 드래그 업로드:
   - `public/index.html`
   - `api/chat.js`
   - `package.json`
   - `vercel.json`
6. "Commit changes" 클릭

---

## STEP 2 — Vercel에 배포

1. vercel.com → "Add New Project"
2. "Import Git Repository" → mri-academy 선택
3. Framework Preset: **Other** 선택
4. "Deploy" 클릭 (1~2분 소요)

---

## STEP 3 — API 키 환경변수 설정 (챗봇 활성화)

1. Vercel 대시보드 → 프로젝트 → Settings → Environment Variables
2. Name: `ANTHROPIC_API_KEY`
3. Value: (Anthropic 콘솔에서 발급한 키 붙여넣기)
4. "Save" → Deployments → "Redeploy"

---

## 완료

배포 후 Vercel이 제공하는 주소: `https://mri-academy-xxxx.vercel.app`

커스텀 도메인 연결 원하면 Vercel → Settings → Domains에서 추가.
